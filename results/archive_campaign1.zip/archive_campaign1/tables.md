## End-to-end response time (us), median / p95 / p99 with 95% bootstrap CI

| config | B | p50 | p95 | p99 | img/s at p50 |
|---|---|---|---|---|---|
| flat_custom_T1 | 1 | 22.4 [22.3, 22.5] | 40.4 [37.5, 43.0] | 72.0 [66.2, 78.3] | 44599 |
| flat_custom_T1 | 64 | 509.3 [507.7, 510.9] | 562.0 [554.3, 579.6] | 690.2 [595.3, 819.2] | 125654 |
| flat_custom_T1 | 256 | 2184.8 [2177.7, 2193.9] | 2349.1 [2302.4, 2478.0] | 2704.2 [2610.7, 2781.1] | 117175 |
| flat_custom_T1_scalar | 1 | 154.3 [153.8, 154.7] | 209.3 [205.1, 212.4] | 290.7 [257.8, 403.1] | 6482 |
| flat_custom_T1_scalar | 64 | 8763.3 [8448.7, 8898.0] | 10138.3 [9737.8, 11458.8] | 14674.7 [13367.0, 16317.4] | 7303 |
| flat_custom_T1_scalar | 256 | 34198.2 [33254.2, 34937.2] | 42309.0 [40918.6, 44028.8] | 48019.3 [44840.4, 65262.2] | 7486 |
| flat_custom_T1_simd | 1 | 31.8 [31.7, 31.8] | 53.4 [51.5, 55.1] | 84.4 [79.2, 92.1] | 31468 |
| flat_custom_T1_simd | 64 | 1547.9 [1539.1, 1552.5] | 1711.2 [1685.8, 1805.0] | 2071.3 [1911.7, 2393.9] | 41347 |
| flat_custom_T1_simd | 256 | 6144.3 [6129.8, 6162.8] | 8299.7 [7675.9, 9089.6] | 9286.3 [9176.2, 9393.6] | 41664 |
| flat_custom_T1_simd_ilp | 1 | 21.7 [21.6, 21.7] | 35.9 [34.2, 37.5] | 63.3 [59.3, 67.1] | 46136 |
| flat_custom_T1_simd_ilp | 64 | 875.7 [870.9, 880.0] | 1254.0 [1138.3, 1274.3] | 1314.8 [1288.5, 1319.4] | 73085 |
| flat_custom_T1_simd_ilp | 256 | 3240.0 [3218.6, 3278.3] | 4738.2 [4314.7, 4816.4] | 5157.8 [4982.8, 5611.2] | 79011 |
| flat_custom_T2 | 1 | 19.2 [19.1, 19.2] | 30.6 [29.5, 32.9] | 56.4 [52.9, 60.6] | 52207 |
| flat_custom_T2 | 64 | 272.5 [268.4, 274.7] | 500.0 [467.0, 515.8] | 657.9 [528.3, 745.7] | 234840 |
| flat_custom_T2 | 256 | 1033.7 [1030.1, 1038.0] | 1250.5 [1201.9, 1294.6] | 1438.2 [1356.6, 1524.3] | 247646 |
| flat_custom_T4 | 1 | 127.8 [127.5, 128.2] | 161.0 [158.8, 163.3] | 230.9 [202.8, 267.5] | 7822 |
| flat_custom_T4 | 64 | 387.4 [384.2, 390.6] | 617.4 [583.9, 716.2] | 1170.9 [996.0, 1285.8] | 165197 |
| flat_custom_T4 | 256 | 1138.1 [1133.1, 1141.4] | 1779.2 [1650.6, 1922.6] | 2543.5 [2201.2, 3443.2] | 224939 |
| flat_torch_T1 | 1 | 59.5 [59.4, 59.7] | 112.3 [110.8, 114.2] | 133.2 [129.3, 136.2] | 16796 |
| flat_torch_T1 | 64 | 491.8 [480.0, 498.3] | 631.6 [573.3, 685.5] | 753.3 [723.9, 791.6] | 130135 |
| flat_torch_T1 | 256 | 1456.3 [1449.7, 1463.3] | 1577.6 [1564.9, 1602.7] | 1779.0 [1648.3, 1842.3] | 175783 |
| flat_torch_T2 | 1 | 56.2 [56.0, 56.4] | 97.1 [95.5, 98.5] | 129.6 [120.5, 137.9] | 17800 |
| flat_torch_T2 | 64 | 321.5 [318.5, 327.1] | 487.0 [467.1, 513.1] | 562.7 [531.9, 751.5] | 199050 |
| flat_torch_T2 | 256 | 876.4 [869.6, 880.9] | 1259.5 [1233.8, 1311.8] | 1468.1 [1339.0, 1636.8] | 292108 |
| flat_torch_T4 | 1 | 170.4 [169.7, 171.1] | 229.0 [226.4, 232.2] | 317.5 [292.2, 339.5] | 5868 |
| flat_torch_T4 | 64 | 623.9 [619.0, 629.6] | 732.3 [714.4, 750.3] | 876.7 [767.9, 1113.1] | 102581 |
| flat_torch_T4 | 256 | 1332.2 [1321.6, 1342.8] | 1607.4 [1526.2, 1692.9] | 2925.2 [1857.6, 5359.7] | 192166 |
| hier_custom_T1 | 1 | 20.7 [20.6, 20.9] | 35.8 [34.1, 38.0] | 72.3 [62.6, 79.6] | 48224 |
| hier_custom_T1 | 64 | 284.2 [281.4, 287.3] | 335.9 [330.0, 342.4] | 402.3 [362.0, 587.8] | 225210 |
| hier_custom_T1 | 256 | 1131.0 [1126.5, 1134.8] | 1215.8 [1198.2, 1229.1] | 1417.2 [1261.0, 1644.2] | 226343 |
| hier_custom_T1_scalar | 1 | 80.6 [79.1, 81.9] | 132.1 [130.1, 134.3] | 173.0 [161.4, 182.3] | 12410 |
| hier_custom_T1_scalar | 64 | 4482.9 [4457.1, 4519.1] | 5030.4 [4924.5, 5229.0] | 8411.6 [6029.4, 9801.0] | 14277 |
| hier_custom_T1_scalar | 256 | 16622.8 [16510.9, 16929.2] | 19055.4 [18633.6, 19161.9] | 21067.9 [19746.7, 22200.6] | 15401 |
| hier_custom_T1_simd | 1 | 21.3 [21.2, 21.4] | 35.4 [34.1, 37.2] | 60.1 [54.6, 68.0] | 46891 |
| hier_custom_T1_simd | 64 | 763.9 [760.1, 769.1] | 893.4 [859.1, 937.0] | 1159.3 [1028.3, 1305.5] | 83781 |
| hier_custom_T1_simd | 256 | 2966.3 [2954.9, 2982.6] | 4334.3 [4071.6, 4459.3] | 4803.0 [4554.0, 5296.3] | 86303 |
| hier_custom_T1_simd_ilp | 1 | 16.7 [16.7, 16.8] | 25.8 [25.0, 27.0] | 53.4 [48.4, 58.7] | 59730 |
| hier_custom_T1_simd_ilp | 64 | 353.2 [350.4, 355.7] | 456.2 [448.6, 462.6] | 500.1 [478.3, 542.0] | 181181 |
| hier_custom_T1_simd_ilp | 256 | 1397.6 [1386.3, 1406.6] | 1858.0 [1817.0, 1886.4] | 1947.1 [1923.1, 2023.1] | 183168 |
| hier_custom_T2 | 1 | 22.1 [22.0, 22.2] | 38.2 [35.5, 40.0] | 65.9 [60.2, 73.1] | 45249 |
| hier_custom_T2 | 64 | 184.8 [181.5, 189.5] | 256.1 [249.7, 265.2] | 415.2 [295.7, 512.0] | 346291 |
| hier_custom_T2 | 256 | 632.2 [628.4, 635.7] | 770.0 [742.6, 786.7] | 831.0 [798.6, 866.0] | 404927 |
| hier_custom_T4 | 1 | 213.7 [213.1, 214.2] | 271.4 [268.2, 276.0] | 412.9 [369.8, 475.4] | 4680 |
| hier_custom_T4 | 64 | 543.5 [540.2, 547.6] | 669.9 [632.0, 742.7] | 937.6 [817.5, 1248.1] | 117756 |
| hier_custom_T4 | 256 | 981.9 [977.5, 987.6] | 1315.2 [1261.5, 1397.5] | 1938.6 [1599.4, 2899.1] | 260732 |
| hier_torch_T1 | 1 | 108.0 [107.6, 108.8] | 192.8 [188.5, 196.3] | 257.6 [248.2, 269.8] | 9258 |
| hier_torch_T1 | 64 | 553.9 [543.7, 561.4] | 681.1 [668.5, 696.6] | 732.2 [716.2, 740.2] | 115547 |
| hier_torch_T1 | 256 | 1319.0 [1298.3, 1334.6] | 1542.9 [1527.4, 1569.7] | 1659.1 [1621.7, 1814.5] | 194084 |
| hier_torch_T2 | 1 | 104.3 [103.9, 104.8] | 170.7 [168.6, 172.5] | 261.8 [233.3, 299.8] | 9588 |
| hier_torch_T2 | 64 | 508.8 [499.2, 514.7] | 794.8 [761.0, 880.8] | 955.0 [911.5, 1059.0] | 125776 |
| hier_torch_T2 | 256 | 1140.2 [1127.0, 1148.5] | 1464.9 [1412.3, 1532.9] | 1771.4 [1592.6, 2057.2] | 224518 |
| hier_torch_T4 | 1 | 214.3 [213.2, 215.8] | 408.9 [386.3, 436.7] | 593.1 [563.6, 623.6] | 4666 |
| hier_torch_T4 | 64 | 1054.5 [1039.8, 1068.4] | 1487.9 [1427.5, 1573.8] | 2132.5 [1674.1, 2923.1] | 60690 |
| hier_torch_T4 | 256 | 1943.2 [1915.2, 1967.1] | 2807.9 [2723.7, 2956.9] | 3215.1 [3050.6, 3716.3] | 131742 |

## Speedups (ratio of the statistic, 95% CI)

| comparison | p50 | p95 | p99 |
|---|---|---|---|
| S_backend|flat|T1|B1 | 2.66x [2.64, 2.67] faster | 2.78x [2.61, 2.99] | 1.85x [1.70, 2.02] |
| S_backend|hier|T1|B1 | 5.21x [5.17, 5.26] faster | 5.38x [5.04, 5.68] | 3.56x [3.20, 4.15] |
| S_system|torch|T1|B1 | 0.55x [0.55, 0.55] slower | 0.58x [0.57, 0.60] | 0.52x [0.49, 0.54] |
| S_system|custom|T1|B1 | 1.08x [1.07, 1.09] faster | 1.13x [1.02, 1.23] | 1.00x [0.87, 1.16] |
| S_backend|flat|T1|B64 | 0.97x [0.94, 0.98] slower | 1.12x [1.02, 1.22] | 1.09x [0.91, 1.30] |
| S_backend|hier|T1|B64 | 1.95x [1.91, 1.98] faster | 2.03x [1.96, 2.09] | 1.82x [1.23, 2.06] |
| S_system|torch|T1|B64 | 0.89x [0.86, 0.91] slower | 0.93x [0.84, 1.01] | 1.03x [0.97, 1.10] |
| S_system|custom|T1|B64 | 1.79x [1.77, 1.81] faster | 1.67x [1.63, 1.73] | 1.72x [1.06, 2.09] |
| S_backend|flat|T1|B256 | 0.67x [0.66, 0.67] slower | 0.67x [0.64, 0.69] | 0.66x [0.61, 0.70] |
| S_backend|hier|T1|B256 | 1.17x [1.15, 1.18] faster | 1.27x [1.25, 1.30] | 1.17x [1.00, 1.38] |
| S_system|torch|T1|B256 | 1.10x [1.09, 1.12] faster | 1.02x [1.00, 1.04] | 1.07x [0.96, 1.13] |
| S_system|custom|T1|B256 | 1.93x [1.92, 1.94] faster | 1.93x [1.89, 2.05] | 1.91x [1.61, 2.16] |
| S_backend|flat|T2|B1 | 2.93x [2.92, 2.95] faster | 3.17x [2.95, 3.30] | 2.30x [2.06, 2.55] |
| S_backend|hier|T2|B1 | 4.72x [4.70, 4.75] faster | 4.47x [4.25, 4.79] | 3.97x [3.42, 4.71] |
| S_system|torch|T2|B1 | 0.54x [0.54, 0.54] slower | 0.57x [0.56, 0.58] | 0.50x [0.43, 0.57] |
| S_system|custom|T2|B1 | 0.87x [0.86, 0.87] slower | 0.80x [0.75, 0.88] | 0.86x [0.74, 0.96] |
| S_backend|flat|T2|B64 | 1.18x [1.17, 1.21] faster | 0.97x [0.92, 1.06] | 0.86x [0.73, 1.39] |
| S_backend|hier|T2|B64 | 2.75x [2.66, 2.81] faster | 3.10x [2.91, 3.46] | 2.30x [1.80, 3.37] |
| S_system|torch|T2|B64 | 0.63x [0.62, 0.65] slower | 0.61x [0.54, 0.67] | 0.59x [0.51, 0.82] |
| S_system|custom|T2|B64 | 1.47x [1.43, 1.50] faster | 1.95x [1.81, 2.03] | 1.58x [1.05, 2.32] |
| S_backend|flat|T2|B256 | 0.85x [0.84, 0.85] slower | 1.01x [0.97, 1.06] | 1.02x [0.88, 1.18] |
| S_backend|hier|T2|B256 | 1.80x [1.78, 1.82] faster | 1.90x [1.82, 2.02] | 2.13x [1.89, 2.53] |
| S_system|torch|T2|B256 | 0.77x [0.76, 0.78] slower | 0.86x [0.82, 0.90] | 0.83x [0.67, 0.98] |
| S_system|custom|T2|B256 | 1.64x [1.62, 1.65] faster | 1.62x [1.55, 1.70] | 1.73x [1.60, 1.88] |
| S_backend|flat|T4|B1 | 1.33x [1.33, 1.34] faster | 1.42x [1.40, 1.45] | 1.37x [1.15, 1.60] |
| S_backend|hier|T4|B1 | 1.00x [1.00, 1.01] no measurable change | 1.51x [1.42, 1.61] | 1.44x [1.24, 1.62] |
| S_system|torch|T4|B1 | 0.80x [0.79, 0.80] slower | 0.56x [0.52, 0.60] | 0.54x [0.49, 0.58] |
| S_system|custom|T4|B1 | 0.60x [0.60, 0.60] slower | 0.59x [0.58, 0.60] | 0.56x [0.46, 0.67] |
| S_backend|flat|T4|B64 | 1.61x [1.59, 1.63] faster | 1.19x [1.01, 1.26] | 0.75x [0.62, 1.07] |
| S_backend|hier|T4|B64 | 1.94x [1.91, 1.97] faster | 2.22x [2.00, 2.42] | 2.27x [1.54, 3.36] |
| S_system|torch|T4|B64 | 0.59x [0.58, 0.60] slower | 0.49x [0.46, 0.52] | 0.41x [0.28, 0.58] |
| S_system|custom|T4|B64 | 0.71x [0.71, 0.72] slower | 0.92x [0.82, 1.09] | 1.25x [0.87, 1.49] |
| S_backend|flat|T4|B256 | 1.17x [1.16, 1.18] faster | 0.90x [0.82, 0.99] | 1.15x [0.62, 2.23] |
| S_backend|hier|T4|B256 | 1.98x [1.95, 2.00] faster | 2.13x [1.98, 2.28] | 1.66x [1.08, 2.21] |
| S_system|torch|T4|B256 | 0.69x [0.68, 0.70] slower | 0.57x [0.54, 0.61] | 0.91x [0.56, 1.71] |
| S_system|custom|T4|B256 | 1.16x [1.15, 1.17] faster | 1.35x [1.21, 1.48] | 1.31x [0.81, 2.06] |
| S_overall(flat torch / hier custom)|T1|B1 | 2.87x [2.85, 2.90] faster | 3.14x [2.95, 3.31] | 1.84x [1.66, 2.13] |
| S_overall(flat torch / hier custom)|T1|B64 | 1.73x [1.69, 1.76] faster | 1.88x [1.70, 2.05] | 1.87x [1.25, 2.15] |
| S_overall(flat torch / hier custom)|T1|B256 | 1.29x [1.28, 1.30] faster | 1.30x [1.28, 1.33] | 1.26x [1.06, 1.42] |
| S_overall(flat torch / hier custom)|T2|B1 | 2.54x [2.53, 2.55] faster | 2.54x [2.42, 2.72] | 1.97x [1.71, 2.24] |
| S_overall(flat torch / hier custom)|T2|B64 | 1.74x [1.70, 1.79] faster | 1.90x [1.79, 2.02] | 1.36x [1.04, 2.26] |
| S_overall(flat torch / hier custom)|T2|B256 | 1.39x [1.37, 1.40] faster | 1.64x [1.59, 1.72] | 1.77x [1.57, 2.01] |

## Thread scaling L(T=1)/L(T)

| config | p50 | verdict |
|---|---|---|
| flat|torch|T2|B1 | 1.06x [1.06, 1.06] | faster |
| flat|torch|T2|B64 | 1.53x [1.48, 1.56] | faster |
| flat|torch|T2|B256 | 1.66x [1.65, 1.68] | faster |
| flat|torch|T4|B1 | 0.35x [0.35, 0.35] | slower |
| flat|torch|T4|B64 | 0.79x [0.77, 0.80] | slower |
| flat|torch|T4|B256 | 1.09x [1.08, 1.10] | faster |
| flat|custom|T2|B1 | 1.17x [1.17, 1.18] | faster |
| flat|custom|T2|B64 | 1.87x [1.85, 1.90] | faster |
| flat|custom|T2|B256 | 2.11x [2.10, 2.12] | faster |
| flat|custom|T4|B1 | 0.18x [0.17, 0.18] | slower |
| flat|custom|T4|B64 | 1.31x [1.30, 1.33] | faster |
| flat|custom|T4|B256 | 1.92x [1.91, 1.93] | faster |
| hier|torch|T2|B1 | 1.04x [1.03, 1.04] | faster |
| hier|torch|T2|B64 | 1.09x [1.07, 1.12] | faster |
| hier|torch|T2|B256 | 1.16x [1.14, 1.18] | faster |
| hier|torch|T4|B1 | 0.50x [0.50, 0.51] | slower |
| hier|torch|T4|B64 | 0.53x [0.51, 0.54] | slower |
| hier|torch|T4|B256 | 0.68x [0.67, 0.69] | slower |
| hier|custom|T2|B1 | 0.94x [0.93, 0.95] | slower |
| hier|custom|T2|B64 | 1.54x [1.50, 1.57] | faster |
| hier|custom|T2|B256 | 1.79x [1.78, 1.80] | faster |
| hier|custom|T4|B1 | 0.10x [0.10, 0.10] | slower |
| hier|custom|T4|B64 | 0.52x [0.52, 0.53] | slower |
| hier|custom|T4|B256 | 1.15x [1.14, 1.16] | faster |

## Dense-kernel ablation (784->256 + bias + ReLU)

| variant | B | p50 us [CI] | p99 us | GFLOP/s | weight GB/s |
|---|---|---|---|---|---|
| blocked_1T | B1 | 6.69 [6.69, 6.70] | 20.00 | 60.0 | 120.0 |
| blocked_1T | B64 | 398.55 [397.15, 399.93] | 558.79 | 64.5 | 2.0 |
| blocked_1T | B256 | 1600.47 [1596.85, 1603.46] | 1912.47 | 64.2 | 0.5 |
| blocked_omp_1T | B1 | 8.53 [8.53, 8.54] | 23.06 | 47.0 | 94.1 |
| blocked_omp_1T | B64 | 370.26 [354.92, 376.69] | 566.02 | 69.4 | 2.2 |
| blocked_omp_1T | B256 | 1599.82 [1593.75, 1605.29] | 2189.01 | 64.2 | 0.5 |
| blocked_omp_2T | B1 | 6.33 [6.32, 6.33] | 19.79 | 63.5 | 126.9 |
| blocked_omp_2T | B64 | 207.00 [205.93, 208.65] | 2265.39 | 124.1 | 3.9 |
| blocked_omp_2T | B256 | 838.69 [832.09, 845.31] | 1866.91 | 122.5 | 1.0 |
| blocked_omp_4T | B1 | 56.56 [56.34, 56.80] | 101.38 | 7.1 | 14.2 |
| blocked_omp_4T | B64 | 249.97 [249.21, 251.36] | 424.97 | 102.8 | 3.2 |
| blocked_omp_4T | B256 | 883.34 [879.03, 887.50] | 1479.40 | 116.3 | 0.9 |
| scalar_1T | B1 | 117.17 [114.89, 117.67] | 158.80 | 3.4 | 6.9 |
| scalar_1T | B64 | 7092.29 [6964.93, 7317.66] | 10217.86 | 3.6 | 0.1 |
| scalar_1T | B256 | 29421.40 [29258.50, 30140.82] | 39442.97 | 3.5 | 0.0 |
| simd_1T | B1 | 15.99 [15.99, 15.99] | 34.12 | 25.1 | 50.2 |
| simd_1T | B64 | 1186.82 [1183.57, 1189.72] | 1890.22 | 21.6 | 0.7 |
| simd_1T | B256 | 4739.13 [4733.03, 4748.22] | 11971.01 | 21.7 | 0.2 |
| simd_ilp_1T | B1 | 9.34 [9.34, 9.34] | 24.44 | 43.0 | 86.0 |
| simd_ilp_1T | B64 | 774.16 [771.82, 776.12] | 940.06 | 33.2 | 1.0 |
| simd_ilp_1T | B256 | 2524.13 [2508.04, 2538.07] | 3427.27 | 40.7 | 0.3 |
| simd_omp_1T | B1 | 15.91 [15.91, 15.92] | 39.40 | 25.2 | 50.4 |
| simd_omp_1T | B64 | 1186.33 [1184.04, 1188.20] | 1429.53 | 21.7 | 0.7 |
| simd_omp_1T | B256 | 4716.10 [4703.49, 4726.33] | 5111.40 | 21.8 | 0.2 |
| simd_omp_2T | B1 | 11.18 [11.16, 11.20] | 31.32 | 35.9 | 71.8 |
| simd_omp_2T | B64 | 636.65 [633.10, 639.31] | 1208.21 | 40.4 | 1.3 |
| simd_omp_2T | B256 | 2554.27 [2539.41, 2564.35] | 3747.87 | 40.2 | 0.3 |
| simd_omp_4T | B1 | 55.69 [55.52, 55.88] | 92.10 | 7.2 | 14.4 |
| simd_omp_4T | B64 | 673.43 [670.25, 676.25] | 1115.06 | 38.1 | 1.2 |
| simd_omp_4T | B256 | 2673.75 [2649.53, 2700.32] | 6948.23 | 38.4 | 0.3 |
| torch_linear_1T | B1 | 14.08 [14.07, 14.09] | 40.10 | 28.5 | 57.0 |
| torch_linear_1T | B64 | 204.43 [203.37, 205.03] | 330.89 | 125.7 | 3.9 |
| torch_linear_1T | B256 | 858.83 [856.31, 861.14] | 1403.59 | 119.7 | 0.9 |
| torch_linear_2T | B1 | 11.57 [11.56, 11.59] | 37.30 | 34.7 | 69.4 |
| torch_linear_2T | B64 | 137.49 [135.78, 139.21] | 262.51 | 186.9 | 5.8 |
| torch_linear_2T | B256 | 536.94 [531.54, 542.69] | 914.31 | 191.4 | 1.5 |
| torch_linear_4T | B1 | 54.48 [54.25, 54.62] | 169.69 | 7.4 | 14.7 |
| torch_linear_4T | B64 | 184.22 [182.91, 185.92] | 447.88 | 139.5 | 4.4 |
| torch_linear_4T | B256 | 591.23 [586.70, 595.24] | 1053.92 | 173.8 | 1.4 |

| step | p50 speedup |
|---|---|
| step scalar_1T->simd_1T|B1 | 7.33x [7.18, 7.36] faster |
| step simd_1T->simd_ilp_1T|B1 | 1.71x [1.71, 1.71] faster |
| step simd_ilp_1T->blocked_1T|B1 | 1.40x [1.39, 1.40] faster |
| step blocked_1T->blocked_omp_2T|B1 | 1.06x [1.06, 1.06] faster |
| cmp simd_omp_1T->simd_omp_2T|B1 | 1.42x [1.42, 1.43] faster |
| cmp blocked_omp_1T->blocked_omp_2T|B1 | 1.35x [1.35, 1.35] faster |
| cmp blocked_omp_2T->blocked_omp_4T|B1 | 0.11x [0.11, 0.11] slower |
| cmp simd_1T->simd_omp_1T|B1 | 1.00x [1.00, 1.01] faster |
| cmp blocked_1T->blocked_omp_1T|B1 | 0.78x [0.78, 0.78] slower |
| cmp torch_linear_1T->blocked_1T|B1 | 2.10x [2.10, 2.11] faster |
| cmp torch_linear_2T->blocked_omp_2T|B1 | 1.83x [1.83, 1.83] faster |
| cmp scalar_1T->blocked_omp_2T|B1 | 18.52x [18.16, 18.61] faster |
| step scalar_1T->simd_1T|B64 | 5.98x [5.87, 6.17] faster |
| step simd_1T->simd_ilp_1T|B64 | 1.53x [1.53, 1.54] faster |
| step simd_ilp_1T->blocked_1T|B64 | 1.94x [1.93, 1.95] faster |
| step blocked_1T->blocked_omp_2T|B64 | 1.93x [1.91, 1.94] faster |
| cmp simd_omp_1T->simd_omp_2T|B64 | 1.86x [1.85, 1.87] faster |
| cmp blocked_omp_1T->blocked_omp_2T|B64 | 1.79x [1.71, 1.82] faster |
| cmp blocked_omp_2T->blocked_omp_4T|B64 | 0.83x [0.82, 0.83] slower |
| cmp simd_1T->simd_omp_1T|B64 | 1.00x [1.00, 1.00] no measurable change |
| cmp blocked_1T->blocked_omp_1T|B64 | 1.08x [1.06, 1.12] faster |
| cmp torch_linear_1T->blocked_1T|B64 | 0.51x [0.51, 0.52] slower |
| cmp torch_linear_2T->blocked_omp_2T|B64 | 0.66x [0.65, 0.67] slower |
| cmp scalar_1T->blocked_omp_2T|B64 | 34.26x [33.60, 35.33] faster |
| step scalar_1T->simd_1T|B256 | 6.21x [6.17, 6.36] faster |
| step simd_1T->simd_ilp_1T|B256 | 1.88x [1.87, 1.89] faster |
| step simd_ilp_1T->blocked_1T|B256 | 1.58x [1.57, 1.59] faster |
| step blocked_1T->blocked_omp_2T|B256 | 1.91x [1.89, 1.92] faster |
| cmp simd_omp_1T->simd_omp_2T|B256 | 1.85x [1.84, 1.86] faster |
| cmp blocked_omp_1T->blocked_omp_2T|B256 | 1.91x [1.89, 1.92] faster |
| cmp blocked_omp_2T->blocked_omp_4T|B256 | 0.95x [0.94, 0.96] slower |
| cmp simd_1T->simd_omp_1T|B256 | 1.00x [1.00, 1.01] faster |
| cmp blocked_1T->blocked_omp_1T|B256 | 1.00x [1.00, 1.00] no measurable change |
| cmp torch_linear_1T->blocked_1T|B256 | 0.54x [0.53, 0.54] slower |
| cmp torch_linear_2T->blocked_omp_2T|B256 | 0.64x [0.63, 0.65] slower |
| cmp scalar_1T->blocked_omp_2T|B256 | 35.08x [34.72, 36.04] faster |

## Kernel choice at system level (custom, 1 thread)

- flat|scalar|B1: p50 154.3 [153.8, 154.7] us, vs scalar 1.00x [1.00, 1.00]
- flat|scalar|B64: p50 8763.3 [8448.7, 8898.0] us, vs scalar 1.00x [1.00, 1.00]
- flat|scalar|B256: p50 34198.2 [33254.2, 34937.2] us, vs scalar 1.00x [1.00, 1.00]
- flat|simd|B1: p50 31.8 [31.7, 31.8] us, vs scalar 4.85x [4.84, 4.87]
- flat|simd|B64: p50 1547.9 [1539.1, 1552.5] us, vs scalar 5.66x [5.46, 5.76]
- flat|simd|B256: p50 6144.3 [6129.8, 6162.8] us, vs scalar 5.57x [5.41, 5.69]
- flat|simd_ilp|B1: p50 21.7 [21.6, 21.7] us, vs scalar 7.12x [7.09, 7.14]
- flat|simd_ilp|B64: p50 875.7 [870.9, 880.0] us, vs scalar 10.01x [9.65, 10.17]
- flat|simd_ilp|B256: p50 3240.0 [3218.6, 3278.3] us, vs scalar 10.55x [10.23, 10.80]
- flat|blocked|B1: p50 22.4 [22.3, 22.5] us, vs scalar 6.88x [6.84, 6.91]
- flat|blocked|B64: p50 509.3 [507.7, 510.9] us, vs scalar 17.21x [16.61, 17.49]
- flat|blocked|B256: p50 2184.8 [2177.7, 2193.9] us, vs scalar 15.65x [15.19, 16.01]
- hier|scalar|B1: p50 80.6 [79.1, 81.9] us, vs scalar 1.00x [1.00, 1.00]
- hier|scalar|B64: p50 4482.9 [4457.1, 4519.1] us, vs scalar 1.00x [1.00, 1.00]
- hier|scalar|B256: p50 16622.8 [16510.9, 16929.2] us, vs scalar 1.00x [1.00, 1.00]
- hier|simd|B1: p50 21.3 [21.2, 21.4] us, vs scalar 3.78x [3.71, 3.84]
- hier|simd|B64: p50 763.9 [760.1, 769.1] us, vs scalar 5.87x [5.82, 5.92]
- hier|simd|B256: p50 2966.3 [2954.9, 2982.6] us, vs scalar 5.60x [5.56, 5.71]
- hier|simd_ilp|B1: p50 16.7 [16.7, 16.8] us, vs scalar 4.81x [4.72, 4.90]
- hier|simd_ilp|B64: p50 353.2 [350.4, 355.7] us, vs scalar 12.69x [12.58, 12.83]
- hier|simd_ilp|B256: p50 1397.6 [1386.3, 1406.6] us, vs scalar 11.89x [11.80, 12.13]
- hier|blocked|B1: p50 20.7 [20.6, 20.9] us, vs scalar 3.89x [3.81, 3.96]
- hier|blocked|B64: p50 284.2 [281.4, 287.3] us, vs scalar 15.77x [15.60, 15.97]
- hier|blocked|B256: p50 1131.0 [1126.5, 1134.8] us, vs scalar 14.70x [14.59, 14.98]

## Stage breakdown at B=1 (median us)

- flat_custom_T1: total_ns=22.8, preprocess_ns=0.5, router_or_forward_ns=10.8, specialists_ns=0.0, pack_scatter_ns=0.0, outside_stages_median_us=10.9, compute_only_median_us=10.8
- flat_custom_T1_scalar: total_ns=149.4, preprocess_ns=0.6, router_or_forward_ns=138.2, specialists_ns=0.0, pack_scatter_ns=0.0, outside_stages_median_us=11.1, compute_only_median_us=138.2
- flat_custom_T1_simd: total_ns=31.0, preprocess_ns=0.4, router_or_forward_ns=20.8, specialists_ns=0.0, pack_scatter_ns=0.0, outside_stages_median_us=8.8, compute_only_median_us=20.8
- flat_custom_T1_simd_ilp: total_ns=21.1, preprocess_ns=0.5, router_or_forward_ns=11.3, specialists_ns=0.0, pack_scatter_ns=0.0, outside_stages_median_us=8.9, compute_only_median_us=11.3
- flat_custom_T2: total_ns=20.1, preprocess_ns=2.4, router_or_forward_ns=8.2, specialists_ns=0.0, pack_scatter_ns=0.0, outside_stages_median_us=9.5, compute_only_median_us=8.2
- flat_custom_T4: total_ns=134.9, preprocess_ns=38.9, router_or_forward_ns=73.9, specialists_ns=0.0, pack_scatter_ns=0.0, outside_stages_median_us=20.6, compute_only_median_us=73.9
- flat_torch_T1: total_ns=60.3, preprocess_ns=12.3, router_or_forward_ns=41.2, specialists_ns=0.0, pack_scatter_ns=0.0, outside_stages_median_us=6.3, compute_only_median_us=41.2
- flat_torch_T2: total_ns=56.6, preprocess_ns=12.2, router_or_forward_ns=38.2, specialists_ns=0.0, pack_scatter_ns=0.0, outside_stages_median_us=5.7, compute_only_median_us=38.2
- flat_torch_T4: total_ns=164.7, preprocess_ns=19.5, router_or_forward_ns=130.1, specialists_ns=0.0, pack_scatter_ns=0.0, outside_stages_median_us=12.7, compute_only_median_us=130.1
- hier_custom_T1: total_ns=20.8, preprocess_ns=0.5, router_or_forward_ns=2.7, specialists_ns=3.4, pack_scatter_ns=0.3, outside_stages_median_us=13.3, compute_only_median_us=6.5
- hier_custom_T1_scalar: total_ns=75.1, preprocess_ns=0.5, router_or_forward_ns=25.2, specialists_ns=31.8, pack_scatter_ns=0.2, outside_stages_median_us=11.0, compute_only_median_us=62.3
- hier_custom_T1_simd: total_ns=22.5, preprocess_ns=0.4, router_or_forward_ns=4.8, specialists_ns=6.1, pack_scatter_ns=0.2, outside_stages_median_us=10.9, compute_only_median_us=11.5
- hier_custom_T1_simd_ilp: total_ns=18.3, preprocess_ns=0.4, router_or_forward_ns=3.0, specialists_ns=3.7, pack_scatter_ns=0.2, outside_stages_median_us=11.1, compute_only_median_us=7.0
- hier_custom_T2: total_ns=23.4, preprocess_ns=1.9, router_or_forward_ns=3.8, specialists_ns=4.6, pack_scatter_ns=0.6, outside_stages_median_us=12.5, compute_only_median_us=8.4
- hier_custom_T4: total_ns=212.8, preprocess_ns=35.3, router_or_forward_ns=46.6, specialists_ns=81.2, pack_scatter_ns=23.9, outside_stages_median_us=23.5, compute_only_median_us=128.2
- hier_torch_T1: total_ns=105.4, preprocess_ns=12.8, router_or_forward_ns=24.3, specialists_ns=37.4, pack_scatter_ns=20.9, outside_stages_median_us=7.6, compute_only_median_us=62.5
- hier_torch_T2: total_ns=110.9, preprocess_ns=13.7, router_or_forward_ns=26.4, specialists_ns=39.6, pack_scatter_ns=21.9, outside_stages_median_us=8.0, compute_only_median_us=66.3
- hier_torch_T4: total_ns=254.9, preprocess_ns=19.8, router_or_forward_ns=84.4, specialists_ns=102.4, pack_scatter_ns=34.6, outside_stages_median_us=13.7, compute_only_median_us=185.4

## MPI

- latency|custom|P1|B1: p50 34.6 [34.2, 35.0], p99 116.3 [103.8, 148.3]; rank0 pre_ns=6.2, route_ns=8.3, pack_send_ns=7.4, local_exec_ns=11.0, wait_recv_ns=0.0
- latency|custom|P1|B64: p50 296.2 [290.5, 302.2], p99 585.1 [458.6, 792.7]; rank0 pre_ns=20.7, route_ns=88.9, pack_send_ns=16.7, local_exec_ns=151.1, wait_recv_ns=0.0
- latency|custom|P1|B256: p50 1030.5 [1017.0, 1046.6], p99 1843.4 [1780.1, 2013.2]; rank0 pre_ns=64.0, route_ns=358.0, pack_send_ns=35.3, local_exec_ns=569.4, wait_recv_ns=0.0
- ranks|custom|P1: r0: comm 0.0 ms exec 165.0 ms idle 0.0 ms msgs 0
- throughput|custom|P1: makespan 36.32 ms, 176202 img/s, service p50 1.002 ms, queue p50 18.40 ms
- latency|custom|P2|B1: p50 49.6 [49.4, 49.9], p99 182.7 [162.4, 239.9]; rank0 pre_ns=7.9, route_ns=9.2, pack_send_ns=14.7, local_exec_ns=0.0, wait_recv_ns=13.3
- latency|custom|P2|B64: p50 388.7 [384.1, 393.6], p99 784.5 [715.8, 2848.0]; rank0 pre_ns=22.7, route_ns=106.8, pack_send_ns=51.5, local_exec_ns=0.0, wait_recv_ns=188.7
- latency|custom|P2|B256: p50 1328.5 [1320.3, 1336.0], p99 2127.4 [1941.2, 2427.4]; rank0 pre_ns=76.5, route_ns=394.3, pack_send_ns=150.5, local_exec_ns=0.0, wait_recv_ns=672.9
- ranks|custom|P2: r0: comm 108.1 ms exec 66.7 ms idle 0.0 ms msgs 1527; r1: comm 25.4 ms exec 99.7 ms idle 345.1 ms msgs 1543
- throughput|custom|P2: makespan 24.77 ms, 258403 img/s, service p50 0.911 ms, queue p50 11.75 ms
- latency|custom|P3|B1: p50 63.4 [62.4, 64.2], p99 246.8 [199.7, 304.0]; rank0 pre_ns=8.6, route_ns=9.4, pack_send_ns=16.4, local_exec_ns=0.0, wait_recv_ns=21.1
- latency|custom|P3|B64: p50 367.3 [361.9, 373.8], p99 956.0 [628.7, 3070.9]; rank0 pre_ns=26.1, route_ns=106.8, pack_send_ns=57.2, local_exec_ns=0.0, wait_recv_ns=157.0
- latency|custom|P3|B256: p50 1333.7 [1322.8, 1357.3], p99 2178.8 [1974.3, 2267.4]; rank0 pre_ns=83.8, route_ns=396.3, pack_send_ns=167.7, local_exec_ns=0.0, wait_recv_ns=646.1
- ranks|custom|P3: r0: comm 112.0 ms exec 64.5 ms idle 0.0 ms msgs 1527; r1: comm 28.0 ms exec 63.1 ms idle 379.9 ms msgs 620; r2: comm 39.7 ms exec 39.5 ms idle 378.1 ms msgs 923
- throughput|custom|P3: makespan 25.74 ms, 248604 img/s, service p50 1.006 ms, queue p50 12.61 ms
- latency|custom|P4|B1: p50 67.8 [67.2, 68.7], p99 243.0 [213.0, 285.1]; rank0 pre_ns=8.7, route_ns=9.6, pack_send_ns=16.4, local_exec_ns=0.0, wait_recv_ns=27.6
- latency|custom|P4|B64: p50 409.3 [401.7, 419.1], p99 1419.5 [951.9, 3313.2]; rank0 pre_ns=30.6, route_ns=110.6, pack_send_ns=66.0, local_exec_ns=0.0, wait_recv_ns=178.8
- latency|custom|P4|B256: p50 1204.8 [1188.7, 1226.5], p99 2900.2 [2712.7, 3109.6]; rank0 pre_ns=91.1, route_ns=424.3, pack_send_ns=178.4, local_exec_ns=0.0, wait_recv_ns=477.3
- ranks|custom|P4: r0: comm 96.5 ms exec 70.9 ms idle 0.0 ms msgs 1527; r1: comm 76.8 ms exec 62.7 ms idle 341.7 ms msgs 620; r2: comm 47.0 ms exec 17.0 ms idle 426.4 ms msgs 406; r3: comm 25.8 ms exec 31.7 ms idle 400.3 ms msgs 517
- throughput|custom|P4: makespan 25.04 ms, 255546 img/s, service p50 0.978 ms, queue p50 12.48 ms
- S_L|custom|P2|B1: p50 0.70x [0.69, 0.71] slower; p99 0.64x [0.47, 0.82]
- S_L|custom|P2|B64: p50 0.76x [0.75, 0.78] slower; p99 0.75x [0.17, 1.05]
- S_L|custom|P2|B256: p50 0.78x [0.77, 0.79] slower; p99 0.87x [0.75, 1.03]
- S_throughput|custom|P2: S=1.47 [1.40, 1.66] E=0.73 faster
- S_L|custom|P3|B1: p50 0.55x [0.54, 0.56] slower; p99 0.47x [0.37, 0.62]
- S_L|custom|P3|B64: p50 0.81x [0.79, 0.83] slower; p99 0.61x [0.15, 1.13]
- S_L|custom|P3|B256: p50 0.77x [0.76, 0.79] slower; p99 0.85x [0.80, 1.02]
- S_throughput|custom|P3: S=1.41 [0.90, 1.46] E=0.47 no measurable change
- S_L|custom|P4|B1: p50 0.51x [0.50, 0.52] slower; p99 0.48x [0.39, 0.60]
- S_L|custom|P4|B64: p50 0.72x [0.70, 0.74] slower; p99 0.41x [0.15, 0.74]
- S_L|custom|P4|B256: p50 0.86x [0.84, 0.87] slower; p99 0.64x [0.58, 0.74]
- S_throughput|custom|P4: S=1.45 [0.76, 1.63] E=0.36 no measurable change
- latency|torch|P1|B1: p50 106.8 [105.8, 107.8], p99 292.7 [275.8, 325.6]; rank0 pre_ns=17.3, route_ns=28.9, pack_send_ns=11.7, local_exec_ns=44.1, wait_recv_ns=0.0
- latency|torch|P1|B64: p50 546.4 [542.0, 555.3], p99 876.8 [812.7, 1001.8]; rank0 pre_ns=86.6, route_ns=107.4, pack_send_ns=32.1, local_exec_ns=303.0, wait_recv_ns=0.0
- latency|torch|P1|B256: p50 1232.6 [1211.4, 1241.8], p99 3154.8 [2670.7, 3349.5]; rank0 pre_ns=232.7, route_ns=327.9, pack_send_ns=39.2, local_exec_ns=595.0, wait_recv_ns=0.0
- ranks|torch|P1: r0: comm 0.0 ms exec 220.5 ms idle 0.0 ms msgs 0
- throughput|torch|P1: makespan 53.73 ms, 119117 img/s, service p50 1.390 ms, queue p50 26.86 ms
- latency|torch|P2|B1: p50 143.3 [142.0, 144.6], p99 379.4 [351.5, 400.4]; rank0 pre_ns=20.5, route_ns=35.5, pack_send_ns=20.4, local_exec_ns=0.0, wait_recv_ns=54.9
- latency|torch|P2|B64: p50 710.8 [702.5, 721.6], p99 1252.3 [1170.1, 1363.3]; rank0 pre_ns=89.1, route_ns=149.7, pack_send_ns=75.3, local_exec_ns=0.0, wait_recv_ns=360.9
- latency|torch|P2|B256: p50 1604.8 [1592.9, 1619.1], p99 2320.2 [2175.2, 2444.2]; rank0 pre_ns=272.4, route_ns=390.8, pack_send_ns=167.7, local_exec_ns=0.0, wait_recv_ns=714.3
- ranks|torch|P2: r0: comm 178.5 ms exec 100.2 ms idle 0.0 ms msgs 1527; r1: comm 33.2 ms exec 166.5 ms idle 392.2 ms msgs 1543
- throughput|torch|P2: makespan 41.69 ms, 153512 img/s, service p50 1.580 ms, queue p50 19.87 ms
- latency|torch|P3|B1: p50 227.6 [224.0, 231.7], p99 641.9 [613.6, 678.6]; rank0 pre_ns=28.1, route_ns=42.1, pack_send_ns=25.8, local_exec_ns=0.0, wait_recv_ns=101.1
- latency|torch|P3|B64: p50 894.1 [885.1, 912.4], p99 1341.0 [1280.8, 1397.6]; rank0 pre_ns=122.1, route_ns=176.9, pack_send_ns=93.7, local_exec_ns=0.0, wait_recv_ns=427.5
- latency|torch|P3|B256: p50 1815.9 [1798.3, 1838.2], p99 2628.3 [2359.9, 2807.5]; rank0 pre_ns=286.2, route_ns=399.9, pack_send_ns=179.1, local_exec_ns=0.0, wait_recv_ns=870.5
- ranks|torch|P3: r0: comm 256.4 ms exec 124.4 ms idle 0.0 ms msgs 1527; r1: comm 39.7 ms exec 122.0 ms idle 625.1 ms msgs 620; r2: comm 67.1 ms exec 127.5 ms idle 764.6 ms msgs 923
- throughput|torch|P3: makespan 55.45 ms, 115413 img/s, service p50 1.993 ms, queue p50 30.41 ms
- latency|torch|P4|B1: p50 237.5 [234.3, 241.2], p99 503.3 [478.2, 528.9]; rank0 pre_ns=28.6, route_ns=42.5, pack_send_ns=25.8, local_exec_ns=0.0, wait_recv_ns=119.1
- latency|torch|P4|B64: p50 844.0 [834.1, 852.5], p99 1463.6 [1300.9, 1641.8]; rank0 pre_ns=115.4, route_ns=161.1, pack_send_ns=88.7, local_exec_ns=0.0, wait_recv_ns=428.3
- latency|torch|P4|B256: p50 1501.0 [1491.3, 1509.0], p99 2353.4 [1857.4, 2643.5]; rank0 pre_ns=262.3, route_ns=354.1, pack_send_ns=161.4, local_exec_ns=0.0, wait_recv_ns=660.7
- ranks|torch|P4: r0: comm 240.5 ms exec 99.0 ms idle 0.0 ms msgs 1527; r1: comm 33.1 ms exec 126.8 ms idle 597.2 ms msgs 620; r2: comm 17.4 ms exec 60.1 ms idle 620.3 ms msgs 406; r3: comm 18.8 ms exec 76.4 ms idle 861.0 ms msgs 517
- throughput|torch|P4: makespan 54.33 ms, 117793 img/s, service p50 2.067 ms, queue p50 27.24 ms
- S_L|torch|P2|B1: p50 0.75x [0.74, 0.75] slower; p99 0.77x [0.70, 0.89]
- S_L|torch|P2|B64: p50 0.77x [0.75, 0.78] slower; p99 0.70x [0.63, 0.84]
- S_L|torch|P2|B256: p50 0.77x [0.75, 0.78] slower; p99 1.36x [1.11, 1.52]
- S_throughput|torch|P2: S=1.29 [1.11, 1.80] E=0.64 faster
- S_L|torch|P3|B1: p50 0.47x [0.46, 0.48] slower; p99 0.46x [0.42, 0.51]
- S_L|torch|P3|B64: p50 0.61x [0.60, 0.62] slower; p99 0.65x [0.59, 0.77]
- S_L|torch|P3|B256: p50 0.68x [0.67, 0.69] slower; p99 1.20x [1.02, 1.40]
- S_throughput|torch|P3: S=0.97 [0.73, 1.34] E=0.32 no measurable change
- S_L|torch|P4|B1: p50 0.45x [0.44, 0.46] slower; p99 0.58x [0.53, 0.66]
- S_L|torch|P4|B64: p50 0.65x [0.64, 0.66] slower; p99 0.60x [0.52, 0.75]
- S_L|torch|P4|B256: p50 0.82x [0.81, 0.83] slower; p99 1.34x [1.11, 1.78]
- S_throughput|torch|P4: S=0.99 [0.83, 1.47] E=0.25 no measurable change
- S_backend|P1|B1: p50 3.08x [3.04, 3.13] faster; p99 2.52x [1.97, 2.93]
- S_backend|P1|B64: p50 1.84x [1.80, 1.89] faster; p99 1.50x [1.08, 2.13]
- S_backend|P1|B256: p50 1.20x [1.17, 1.21] faster; p99 1.71x [1.35, 1.86]
- S_backend|P2|B1: p50 2.89x [2.86, 2.92] faster; p99 2.08x [1.51, 2.38]
- S_backend|P2|B64: p50 1.83x [1.80, 1.87] faster; p99 1.60x [0.44, 1.85]
- S_backend|P2|B256: p50 1.21x [1.20, 1.22] faster; p99 1.09x [0.94, 1.26]
- S_backend|P3|B1: p50 3.59x [3.52, 3.68] faster; p99 2.60x [2.08, 3.23]
- S_backend|P3|B64: p50 2.43x [2.38, 2.49] faster; p99 1.40x [0.43, 2.13]
- S_backend|P3|B256: p50 1.36x [1.34, 1.38] faster; p99 1.21x [1.08, 1.33]
- S_backend|P4|B1: p50 3.50x [3.44, 3.56] faster; p99 2.07x [1.73, 2.41]
- S_backend|P4|B64: p50 2.06x [2.01, 2.10] faster; p99 1.03x [0.42, 1.60]
- S_backend|P4|B256: p50 1.25x [1.22, 1.26] faster; p99 0.81x [0.61, 0.95]
